app.controller('dashboardController', function($scope, $http, $location) {

});

