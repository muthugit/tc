# littleBit-Admin
OpenSource CMS using AngularJS &amp; Parse.com
